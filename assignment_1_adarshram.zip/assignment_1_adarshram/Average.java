import java.io.*;
import java.util.*;

public class Average {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        double entered = 1;
        int digits = 0;
        double sum =0;
        System.out.println("Type as many positive numbers as you want. A negative number will quit the program.");
        while (entered >= 0){
           entered = sc.nextDouble();
           if (entered > 0){
              sum = sum + entered;
              digits++;
           }
        }
        System.out.println("Amount of numbers entered: " + digits + ". Numbers averaging: " + sum/digits);
    }
}