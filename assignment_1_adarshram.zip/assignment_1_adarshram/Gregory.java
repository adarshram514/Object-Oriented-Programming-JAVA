public class Gregory {
	public static void main(String[] args) {
		
		int n = Integer.parseInt(args[0]);
		double sum = 0;
		for (int i = 1; i<=n; i++) {
			sum = sum + Math.pow(-1, i + 1) / (2 * i - 1);
		}
		System.out.println("Pi according to Gregory series: " + sum * 4);
		System.out.println("This differs from Java’s value by " + ((Math.PI - sum * 4) / Math.PI) * 100 + " percent");
	}
}