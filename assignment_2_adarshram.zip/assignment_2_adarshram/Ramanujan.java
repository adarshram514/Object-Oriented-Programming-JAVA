public class Ramnujan {

    public static void main(String[] args)
    {
        if(args.length == 0)
        {
            System.out.println("Error: Input number of terms to calculate value of pi in command line");
            return;
        }
        int n = Integer.parseInt(args[0]);
        double sum = 0;
            for(int i = 0; i <= n; i++)
        {
            sum += getTerm(i);
        }
        sum = sum * Math.sqrt(8) / (99*99);
        double calculated_pi = Math.pow(sum, -1);
        double diff = Math.abs(calculated_pi - Math.PI);
        double percError = diff / Math.PI * 100;
        
        System.out.printf("Value of pi using Ramnujan's series with  %d  terms approximates: %.10f\n",
        n, calculated_pi);
        System.out.printf("Math.PI value: %.10f\n", Math.PI);
        System.out.printf("Percentage error between approximated pi and Math.PI: %.5f %%\n", percError);
    }

    public static double getTerm(int n)
    {
        double fact = Factorial.calculate(4*n);
        double fact_n = Factorial.calculate(n);
        double temp1 = Math.pow((Math.pow(4, n) * fact_n), 4);
        double temp2 = (1103 + (26390 * n)) / (Math.pow(99, (4 * n)));
        
        return fact / temp1 * temp2;
    }

}