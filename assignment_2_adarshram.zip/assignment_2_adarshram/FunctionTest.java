public class FunctionTest {

	public static final double EPSILON = 0.00000001;
	public static void main(String[] args) {

	FunctionTest ft = new FunctionTest();

		System.out.println(ft.findRoot(3, 4, EPSILON));
		}

	public double findRoot(double a, double b, double epsilon) {
	
	double x = (a + b) / 2;
		if (Math.abs(a - x) < epsilon) {
		return x;
	
	} else if (evaluate(a) > 0 && evaluate(x) > 0 || evaluate(a) < 0 && evaluate(x) < 0) {
	return findRoot(x, b, EPSILON);
} else {
	return findRoot(a, x, EPSILON);
	}
}
	public double evaluate(double param) {
	return Math.sin(param);
	}
}