public class Factorial {

    public static long calculate(long n) {
        if (n == 0) {
            return 1;
        } else {
            return n * calculate(n-1);
        }
    }
    public static void main(String[] args) {
        long result = Factorial.calculate(0);
        System.out.println("Factorial.calculate(0) returned " + result);
        if (result == 1) {
            System.out.println("Test passed!");
        }
        result = Factorial.calculate(5);
        System.out.println("Factorial.calculate(5) returned " + result);
        if (result == 120) {
            System.out.println("Test passed!");
        }
    }
}