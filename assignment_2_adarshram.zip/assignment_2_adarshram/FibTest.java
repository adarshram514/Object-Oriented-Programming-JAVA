public class FibTest {

	public static int fibIter(int n) {

	int a = 1;
	int b = 1;
	int current = 1;
		for(int i = 3; i <= n; i++) {
		current = a + b;
		b = a;
		a = current;
		}
		return current;
	}
	public static int fibRecur(int n) {
		if(n == 1 || n == 2) {
		return 1;
	
	} else {
	
	return fibRecur(n - 1) + fibRecur(n - 2);
	}
}
	public static void main(String[] args) {
		long start = System.currentTimeMillis();
		fibIter(40);
		long end = System.currentTimeMillis();
	
		System.out.println("Time taken iterative method: " + (end - start));
		start = System.currentTimeMillis();
		fibRecur(40);
		end = System.currentTimeMillis();

	System.out.println("Time taken recursive method: " + (end - start));
	}
}