import java.util.Arrays;

	public class Polynomials {
	private int[] coefficients;
	public Polynomials(int[] coefficients) {
	
	this.coefficients = Arrays.copyOf(coefficients, coefficients.length);
	}

	public Polynomials polyAdd(Polynomials p) {
	
		int maxDegree = (p.degree() > this.degree()) ? p.degree() : this.degree();
		int coefficients[] = new int[1 + maxDegree];
			for(int i=0; i<=this.degree(); i++) {
			coefficients[i] = this.coefficients[i];
		}
			for(int i = 0; i <= p.degree(); i++) {
			coefficients[i] += p.coefficients[i];
		}
		return new Polynomials(coefficients);
	}
	public double evaluate(double x) {

		double result = 0;
			for(int i=this.degree(); i >= 0; i--) {
			result = x *result + this.coefficients[i];
		}
		return result;

	}

@Override

	public String toString() {
	StringBuilder sb = new StringBuilder();

		int p = degree();
		String seperator = "";
			for(int i=coefficients.length-1; i >= 0; i--) {
				if(coefficients[i] > 0) {
				if(p != 0)
			sb.append(seperator + coefficients[i] + "x^" + p);
		else
			sb.append(seperator + coefficients[i]);
		} else if(coefficients[i] < 0) {
			if(p != 0)
			sb.append(" " + coefficients[i] + "x^" + p);
		else
			sb.append(" " + coefficients[i]);
		}
		p--;
		seperator = " + ";
		}
		return sb.toString();
	}
	private int degree() {
		int degree = 0;
			for(int i=0; i<coefficients.length; i++) {
				if(coefficients[i] != 0) {
				degree = i;
			}
		}
		return degree;
	}
	public static void main(String[] args) {
	Polynomials p1 = new Polynomials(new int[]{4,0,-8,0,3,2});

		System.out.println(p1);
		Polynomials p2 = new Polynomials(new int[]{4,3,4, 0, -1});

		System.out.println(p2);
		System.out.println("The degree of p1: " + p1.degree());
		System.out.println("p1 + p2: " + p1.polyAdd(p2));
		System.out.println("Evaluating p1 at x = 2: " + p1.evaluate(2));
	}
}